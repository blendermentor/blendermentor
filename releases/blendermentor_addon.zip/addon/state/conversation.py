# SPDX-License-Identifier: GPL-3.0-or-later
# BlenderMentor — Scene-level conversation state

import bpy


class ChatMessage(bpy.types.PropertyGroup):
    """A single chat message (user or AI)."""
    text: bpy.props.StringProperty(name="Text", default="")
    is_user: bpy.props.BoolProperty(name="Is User", default=True)


class StepItem(bpy.types.PropertyGroup):
    """One step in the AI's structured response."""
    instruction: bpy.props.StringProperty(name="Instruction", default="")
    description: bpy.props.StringProperty(name="Description", default="")
    is_done: bpy.props.BoolProperty(name="Done", default=False)
    # Highlight data stored as a JSON string (parsed at runtime)
    highlight_json: bpy.props.StringProperty(name="Highlight JSON", default="")


# ------------------------------------------------------------------
# Registration helpers
# ------------------------------------------------------------------

_classes = (ChatMessage, StepItem)


def on_message_update(self, context):
    if self.bm_input_text.strip():
        # Schedule the operator execution to avoid context lock during property update
        def run_op():
            bpy.ops.blendermentor.send_message('EXEC_DEFAULT')
            return None
        bpy.app.timers.register(run_op, first_interval=0.01)

def register_properties():
    for cls in _classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.bm_chat_history = bpy.props.CollectionProperty(type=ChatMessage)
    bpy.types.Scene.bm_steps = bpy.props.CollectionProperty(type=StepItem)
    bpy.types.Scene.bm_current_step = bpy.props.IntProperty(
        name="Current Step", default=0, min=0
    )
    bpy.types.Scene.bm_input_text = bpy.props.StringProperty(
        name="Message", default="", update=on_message_update
    )
    # Follow-up question tracking (-1 = fresh question, >= 0 = asking about that step)
    bpy.types.Scene.bm_followup_step = bpy.props.IntProperty(
        name="Follow-up Step", default=-1,
        description="Step index the user is asking about (-1 = fresh question)"
    )
    # Store last AI response JSON for follow-up context
    bpy.types.Scene.bm_last_ai_response = bpy.props.StringProperty(
        name="Last AI Response", default="",
        description="Raw JSON of the last AI response (for follow-up context)"
    )


def unregister_properties():
    del bpy.types.Scene.bm_last_ai_response
    del bpy.types.Scene.bm_followup_step
    del bpy.types.Scene.bm_input_text
    del bpy.types.Scene.bm_current_step
    del bpy.types.Scene.bm_steps
    del bpy.types.Scene.bm_chat_history

    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
